# 2016CCF_BDCI_Sougou
【The Right团队-源码以及PPT分享】2016CCF大数据与计算智能大赛：精准营销中搜狗用户画像挖掘

具体详见我的博客：
[传送门](http://coderskychen.cn/2016/12/28/%E3%80%90%E5%B9%B2%E8%B4%A7%E5%88%86%E4%BA%AB%E3%80%912016CCF%E5%A4%A7%E6%95%B0%E6%8D%AE%E4%B8%8E%E8%AE%A1%E7%AE%97%E6%99%BA%E8%83%BD%E5%A4%A7%E8%B5%9B-%E6%90%9C%E7%8B%97%E7%94%A8%E6%88%B7%E7%94%BB%E5%83%8F%E6%8C%96%E6%8E%98/)

复赛数据下载链接：
http://pan.baidu.com/s/1mi9DjIg 
密码：g8i9

初识python，代码写的很粗糙，多多包涵~
