

import pandas as pd
inputfile='chapter15/out/meidi_jd_process_end.txt'
outputfile='chapter15/out/fenlei.txt'
text=pd.read_csv(inputfile,header=None)
for i in text:
    print(i)
    
